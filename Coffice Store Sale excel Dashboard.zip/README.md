# Coffee-Shop-Sale-Analysis
# Objective

The main objective of this project is to analyze retail sales data to gain actionable insights that will enhance the performance of the Coffee Shop
# Recommended Analysis
## How do sales vary by day of the week and hour of the day?
